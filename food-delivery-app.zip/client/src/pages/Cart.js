import React from 'react';

function Cart() {
  return (
    <div className="container mt-4">
      <h2>Your Cart</h2>
      <p>Cart functionality will be added here.</p>
    </div>
  );
}

export default Cart;