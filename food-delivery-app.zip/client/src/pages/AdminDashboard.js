import React from 'react';

function AdminDashboard() {
  return (
    <div className="container mt-4">
      <h2>Admin Dashboard</h2>
      <p>This is a basic admin panel for managing restaurants and orders.</p>
    </div>
  );
}

export default AdminDashboard;