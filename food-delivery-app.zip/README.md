# Grateful Flavors
A MERN stack food delivery application.